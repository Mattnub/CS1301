// Class: CS 1301
// Term: Summer 2016
// Name: Matthew Whalley
// Instructor: Skinner
// Assignment: 1_4

public class Expression{
     
   public static void main (String[] args){
   
      System.out.print(((9.5 * 4.5) - (2.5 * 3))/(45.5 - 3.5));
   }
}